import {
  pgTable,
  varchar,
  decimal,
  date,
  text,
  timestamp,
  bigserial,
  boolean,
  index,
} from "drizzle-orm/pg-core";

export const airTicket = pgTable(
  "air_ticket",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),

    isTicketBooked: boolean("is_ticket_booked").default(false),

    amount: decimal("amount", { precision: 12, scale: 2 }),

    airTicket: varchar("air_ticket", { length: 50 }),

    ticketDate: date("date"),

    remarks: text("remark"),

    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    isTicketBookedIdx: index("idx_air_ticket_booked").on(
      table.isTicketBooked
    ),

    ticketDateIdx: index("idx_air_ticket_date").on(table.ticketDate),

    createdAtIdx: index("idx_air_ticket_created_at").on(table.createdAt),
  })
);

