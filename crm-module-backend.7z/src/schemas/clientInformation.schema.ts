// clientInformation.schema.ts
// import {
//   pgTable,
//   serial,
//   varchar,
//   date,
//   timestamp,
//   bigserial,
//   bigint,
// } from "drizzle-orm/pg-core";
// import { users } from "./users.schema";
// import { saleTypes } from "./saleType.schema";

// export const clientInformation = pgTable("client_information", {
//   clientId: bigserial("id",{ mode: "number" }).primaryKey(),
//   counsellorId: bigint("counsellor_id", { mode: "number" })
//     .references(() => users.id)
//     .notNull(),
//   fullName: varchar("fullname", { length: 150 }).notNull(),
//   enrollmentDate: date("date").notNull(),
//   saleTypeId: serial("sale_type_id")
//     .references(() => saleTypes.saleTypeId)
//     .notNull(),
//   createdAt: timestamp("created_at").defaultNow(),
// });
import {
  pgTable,
  varchar,
  date,
  timestamp,
  bigserial,
  bigint,
  serial,
  index,
} from "drizzle-orm/pg-core";
import { users } from "./users.schema";
import { saleTypes } from "./saleType.schema";

export const clientInformation = pgTable(
  "client_information",
  {
    clientId: bigserial("id", { mode: "number" }).primaryKey(),

    counsellorId: bigint("counsellor_id", { mode: "number" })
      .references(() => users.id)
      .notNull(),

    fullName: varchar("fullname", { length: 150 }).notNull(),

    enrollmentDate: date("date").notNull(),

    saleTypeId: serial("sale_type_id")
      .references(() => saleTypes.saleTypeId)
      .notNull(),

    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    counsellorIdx: index("idx_client_counsellor").on(table.counsellorId),

    saleTypeIdx: index("idx_client_sale_type").on(table.saleTypeId),

    enrollmentDateIdx: index("idx_client_enrollment_date").on(
      table.enrollmentDate
    ),

    createdAtIdx: index("idx_client_created_at").on(table.createdAt),

    counsellorCreatedIdx: index("idx_client_counsellor_created").on(
      table.counsellorId,
      table.createdAt
    ),
  })
);
