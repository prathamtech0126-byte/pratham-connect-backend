import {
  pgTable,
  decimal,
  date,
  text,
  timestamp,
  bigserial,
  index,
} from "drizzle-orm/pg-core";

export const beaconAccount = pgTable(
  "beacon_account",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),

    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),

    accountDate: date("date"),

    remarks: text("remark"),

    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    accountDateIdx: index("idx_beacon_account_date").on(table.accountDate),

    createdAtIdx: index("idx_beacon_account_created_at").on(table.createdAt),
  })
);

