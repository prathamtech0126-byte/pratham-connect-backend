// activityLog.schema.ts
import {
    pgTable,
    bigserial,
    bigint,
    varchar,
    timestamp,
    jsonb,
    index,
  } from "drizzle-orm/pg-core";
  import { users } from "./users.schema";

  export const activityLog = pgTable(
    "activity_log",
    {
      logId: bigserial("id", { mode: "number" }).primaryKey(),
      entityType: varchar("entity_type", { length: 50 }).notNull(),
      // e.g. 'client', 'client_payment', 'product_payment'
      entityId: bigint("entity_id", { mode: "number" }).notNull(),
      // ID from respective table
      action: varchar("action", { length: 50 }).notNull(),
      // CREATE | UPDATE | DELETE | STATUS_CHANGE | PAYMENT_ADDED
      oldValue: jsonb("old_value"),
      newValue: jsonb("new_value"),
      performedBy: bigint("performed_by", { mode: "number" })
        .references(() => users.id),
      ipAddress: varchar("ip_address", { length: 45 }),
      userAgent: varchar("user_agent", { length: 255 }),
      createdAt: timestamp("created_at").defaultNow(),
    },
    (table) => ({
      entityIdx: index("idx_activity_entity").on(
        table.entityType,
        table.entityId
      ),
      actionIdx: index("idx_activity_action").on(table.action),
      userIdx: index("idx_activity_user").on(table.performedBy),
      createdAtIdx: index("idx_activity_created_at").on(table.createdAt),
    })
  );
