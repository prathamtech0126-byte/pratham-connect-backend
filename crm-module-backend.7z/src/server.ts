import dotenv from "dotenv";
dotenv.config();

import app from "./index";
import { checkDbConnection } from "./config/databaseConnection";

const PORT = process.env.PORT || 5000;

app.listen(PORT, async () => {
  console.log(`🚀 Server running on port ${PORT}`);

  try {
    await checkDbConnection();
  } catch (error) {
    console.error("❌ Database connection failed");
    process.exit(1); // stop app if DB fails
  }
});
