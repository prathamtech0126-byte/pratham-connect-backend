import { db } from "../config/databaseConnection";
import { clientInformation } from "../schemas/clientInformation.schema";
import { clientPayments } from "../schemas/clientPayment.schema";
import { clientProductPayments } from "../schemas/clientProductPayments.schema";
import { saleTypes } from "../schemas/saleType.schema";
import { users } from "../schemas/users.schema";
import { eq } from "drizzle-orm";

/* ==============================
   TYPES
============================== */
interface SaveClientInput {
  clientId?: number; // 👈 optional → if present, update
  fullName: string;
  enrollmentDate: string;
  saleTypeId: number;
}

/* ==============================
   CREATE CLIENT
============================== */
export const saveClient = async (
  data: SaveClientInput,
  counsellorId: number
) => {
  const { clientId, fullName, enrollmentDate, saleTypeId } = data;

  if (!fullName || !enrollmentDate || !saleTypeId) {
    throw new Error("All fields are required");
  }

  // 🔍 validate counsellor
  const counsellor = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.id, counsellorId));

  if (!counsellor.length) {
    throw new Error("Invalid counsellor");
  }

  // 🔍 validate sale type
  const saleType = await db
    .select({ id: saleTypes.saleTypeId })
    .from(saleTypes)
    .where(eq(saleTypes.saleTypeId, saleTypeId));

  if (!saleType.length) {
    throw new Error("Invalid sale type");
  }

  /* ==========================
     UPDATE CLIENT
  ========================== */
  if (clientId) {
    // 🔐 check client belongs to counsellor
    const existingClient = await db
      .select({ id: clientInformation.clientId })
      .from(clientInformation)
      .where(eq(clientInformation.clientId, clientId));

    if (!existingClient.length) {
      throw new Error("Client not found");
    }

    const [updatedClient] = await db
      .update(clientInformation)
      .set({
        fullName,
        enrollmentDate,
        saleTypeId,
      })
      .where(eq(clientInformation.clientId, clientId))
      .returning({
        clientId: clientInformation.clientId,
        counsellorId: clientInformation.counsellorId,
        fullName: clientInformation.fullName,
        enrollmentDate: clientInformation.enrollmentDate,
        saleTypeId: clientInformation.saleTypeId,
      });

    return {
      action: "UPDATED",
      client: updatedClient,
    };
  }

  /* ==========================
     CREATE CLIENT
  ========================== */
  const [newClient] = await db
    .insert(clientInformation)
    .values({
      counsellorId,
      fullName,
      enrollmentDate,
      saleTypeId,
    })
    .returning({
      clientId: clientInformation.clientId,
      counsellorId: clientInformation.counsellorId,
      fullName: clientInformation.fullName,
      enrollmentDate: clientInformation.enrollmentDate,
      saleTypeId: clientInformation.saleTypeId,
    });

  return {
    action: "CREATED",
    client: newClient,
  };
};




export const getClientFullDetailsById = async (clientId: number) => {
  // 1. Get client info
  const [client] = await db
    .select()
    .from(clientInformation)
    .where(eq(clientInformation.clientId, clientId));

  if (!client) return null;

  // 2. Get sale type to check isCoreProduct
  const [saleType] = await db
    .select()
    .from(saleTypes)
    .where(eq(saleTypes.saleTypeId, client.saleTypeId));

  if (!saleType) return null;

  const isCoreProduct = saleType.isCoreProduct;

  // 3. Client product payments (always fetched)
  const productPayments = await db
    .select()
    .from(clientProductPayments)
    .where(eq(clientProductPayments.clientId, clientId));

  // 4. Client payments (only if isCoreProduct is true)
  let payments: any[] = [];
  if (isCoreProduct) {
    payments = await db
      .select()
      .from(clientPayments)
      .where(eq(clientPayments.clientId, clientId));
  }

  return {
    client,
    saleType: {
      saleTypeId: saleType.saleTypeId,
      saleType: saleType.saleType,
      amount: saleType.amount,
      isCoreProduct: saleType.isCoreProduct,
    },
    payments: isCoreProduct ? payments : null,
    productPayments,
  };
};
