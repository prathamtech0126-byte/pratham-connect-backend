import { db } from "../config/databaseConnection";
import { clientPayments } from "../schemas/clientPayment.schema";
import { eq } from "drizzle-orm";

export type PaymentStage =
  | "INITIAL"
  | "BEFORE_VISA"
  | "AFTER_VISA"
  | "SUBMITTED_VISA";

interface SaveClientPaymentInput {
  paymentId?: number; // 👈 optional
  clientId: number;
  totalPayment: string;
  stage: PaymentStage;
  amount: string;
  paymentDate?: string;
  invoiceNo?: string;
  remarks?: string;
}

export const saveClientPayment = async (
  data: SaveClientPaymentInput
) => {
  const {
    paymentId,
    clientId,
    totalPayment,
    stage,
    amount,
    paymentDate,
    invoiceNo,
    remarks,
  } = data;

  if (!clientId || !stage || !amount || !totalPayment) {
    throw new Error("Required payment fields missing");
  }

  /* =========================
     UPDATE PAYMENT
  ========================= */
  if (paymentId) {
    const existingPayment = await db
      .select({ id: clientPayments.paymentId })
      .from(clientPayments)
      .where(eq(clientPayments.paymentId, paymentId));

    if (!existingPayment.length) {
      throw new Error("Payment not found");
    }

    const [updatedPayment] = await db
      .update(clientPayments)
      .set({
        clientId,
        totalPayment,
        stage,
        amount,
        paymentDate: paymentDate ?? null,
        invoiceNo: invoiceNo ?? null,
        remarks: remarks ?? null,
      })
      .where(eq(clientPayments.paymentId, paymentId))
      .returning();

    return {
      action: "UPDATED",
      payment: updatedPayment,
    };
  }

  /* =========================
     CREATE PAYMENT
  ========================= */
  const [newPayment] = await db
    .insert(clientPayments)
    .values({
      clientId,
      totalPayment,
      stage,
      amount,
      paymentDate: paymentDate ?? null,
      invoiceNo: invoiceNo ?? null,
      remarks: remarks ?? null,
    })
    .returning();

  return {
    action: "CREATED",
    payment: newPayment,
  };
};


export const getPaymentsByClientId = async (clientId: number) => {
  return db
    .select()
    .from(clientPayments)
    .where(eq(clientPayments.clientId, clientId));
};
