import { db } from "../config/databaseConnection";
import {
  clientProductPayments,
  productTypeEnum,
  entityTypeEnum,
} from "../schemas/clientProductPayments.schema";
import { clientInformation } from "../schemas/clientInformation.schema";
import { simCard } from "../schemas/simCard.schema";
import { airTicket } from "../schemas/airTicket.schema";
import { ielts } from "../schemas/ielts.schema";
import { loan } from "../schemas/loan.schema";
import { forexCard } from "../schemas/forexCard.schema";
import { forexFees } from "../schemas/forexFees.schema";
import { tutionFees } from "../schemas/tutionFees.schema";
import { insurance } from "../schemas/insurance.schema";
import { beaconAccount } from "../schemas/beaconAccount.schema";
import { creditCard } from "../schemas/creditCard.schema";
import { newSell } from "../schemas/newSell.schema";
import { visaExtension } from "../schemas/visaExtension.schema";
import { eq } from "drizzle-orm";

// Product type enum values
export type ProductType =
  | "ALL_FINANCE_EMPLOYEMENT"
  | "INDIAN_SIDE_EMPLOYEMENT"
  | "NOC_LEVEL_JOB_ARRANGEMENT"
  | "LAWYER_REFUSAL_CHARGE"
  | "ONSHORE_PART_TIME_EMPLOYEMENT"
  | "TRV_WORK_PERMIT_EXT_STUDY_PERMIT_EXTENSION"
  | "MARRIAGE_PHOTO_FOR_COURT_MARRIAGE"
  | "MARRIAGE_PHOTO_CERTIFICATE"
  | "RECENTE_MARRIAGE_RELATIONSHIP_AFFIDAVIT"
  | "JUDICAL_REVIEW_CHARGE"
  | "SIM_CARD_ACTIVATION"
  | "INSURANCE"
  | "BEACON_ACCOUNT"
  | "AIR_TICKET"
  | "OTHER_NEW_SELL"
  | "SPONSOR_CHARGES"
  | "FINANCE_EMPLOYEMENT"
  | "IELTS_ENROLLMENT"
  | "LOAN_DETAILS"
  | "FOREX_CARD"
  | "FOREX_FEES"
  | "TUTION_FEES"
  | "CREDIT_CARD"
  | "VISA_EXTENSION";

// Entity type enum values
export type EntityType =
  | "visaextension_id"
  | "simCard_id"
  | "airTicket_id"
  | "newSell_id"
  | "ielts_id"
  | "loan_id"
  | "forexCard_id"
  | "forexFees_id"
  | "tutionFees_id"
  | "insurance_id"
  | "beaconAccount_id"
  | "creditCard_id";

// Map product name to entity type
const productToEntityTypeMap: Record<ProductType, EntityType> = {
  SIM_CARD_ACTIVATION: "simCard_id",
  AIR_TICKET: "airTicket_id",
  IELTS_ENROLLMENT: "ielts_id",
  LOAN_DETAILS: "loan_id",
  FOREX_CARD: "forexCard_id",
  FOREX_FEES: "forexFees_id",
  TUTION_FEES: "tutionFees_id",
  INSURANCE: "insurance_id",
  BEACON_ACCOUNT: "beaconAccount_id",
  CREDIT_CARD: "creditCard_id",
  OTHER_NEW_SELL: "newSell_id",
  VISA_EXTENSION: "visaextension_id",
  // Products without specific tables use newSell
  ALL_FINANCE_EMPLOYEMENT: "newSell_id",
  INDIAN_SIDE_EMPLOYEMENT: "newSell_id",
  NOC_LEVEL_JOB_ARRANGEMENT: "newSell_id",
  LAWYER_REFUSAL_CHARGE: "newSell_id",
  ONSHORE_PART_TIME_EMPLOYEMENT: "newSell_id",
  TRV_WORK_PERMIT_EXT_STUDY_PERMIT_EXTENSION: "newSell_id",
  MARRIAGE_PHOTO_FOR_COURT_MARRIAGE: "newSell_id",
  MARRIAGE_PHOTO_CERTIFICATE: "newSell_id",
  RECENTE_MARRIAGE_RELATIONSHIP_AFFIDAVIT: "newSell_id",
  JUDICAL_REVIEW_CHARGE: "newSell_id",
  SPONSOR_CHARGES: "newSell_id",
  FINANCE_EMPLOYEMENT: "newSell_id",
};

// Map entity type to table for validation
const entityTypeToTable: Record<EntityType, any> = {
  simCard_id: simCard,
  airTicket_id: airTicket,
  ielts_id: ielts,
  loan_id: loan,
  forexCard_id: forexCard,
  forexFees_id: forexFees,
  tutionFees_id: tutionFees,
  insurance_id: insurance,
  beaconAccount_id: beaconAccount,
  creditCard_id: creditCard,
  newSell_id: newSell,
  visaextension_id: visaExtension,
};

// Entity data interfaces
interface SimCardData {
  activatedStatus?: boolean;
  simcardPlan?: string;
  simCardGivingDate?: string;
  simActivationDate?: string;
  remarks?: string;
}

interface AirTicketData {
  isTicketBooked?: boolean;
  amount?: number | string;
  airTicket?: string;
  ticketDate?: string;
  remarks?: string;
}

interface IeltsData {
  enrolledStatus?: boolean;
  amount: number | string;
  enrollmentDate?: string;
  remarks?: string;
}

interface LoanData {
  amount: number | string;
  disbursmentDate?: string;
  remarks?: string;
}

interface ForexCardData {
  forexCardStatus?: string;
  cardDate?: string;
  remarks?: string;
}

interface ForexFeesData {
  side: "PI" | "TP";
  amount: number | string;
  feeDate?: string;
  remarks?: string;
}

interface TutionFeesData {
  tutionFeesStatus: "paid" | "pending";
  feeDate?: string;
  remarks?: string;
}

interface InsuranceData {
  amount: number | string;
  insuranceDate?: string;
  remarks?: string;
}

interface BeaconAccountData {
  amount: number | string;
  accountDate?: string;
  remarks?: string;
}

interface CreditCardData {
  amount: number | string;
  cardDate?: string;
  remarks?: string;
}

interface VisaExtensionData {
  type: string;
  amount: number | string;
  extensionDate?: string;
  invoiceNo?: string;
  remarks?: string;
}

interface NewSellData {
  serviceName: string;
  serviceInformation?: string;
  amount: number | string;
  sellDate?: string;
  remarks?: string;
}

interface SaveClientProductPaymentInput {
  productPaymentId?: number;
  clientId: number;
  productName: ProductType;
  invoiceNo?: string;
  amount: number | string ;
  paymentDate?: string;
  remarks?: string;
  entityId?: number;
  // Entity data based on product type
  entityData?:
    | SimCardData
    | AirTicketData
    | IeltsData
    | LoanData
    | ForexCardData
    | ForexFeesData
    | TutionFeesData
    | InsuranceData
    | BeaconAccountData
    | CreditCardData
    | VisaExtensionData
    | NewSellData;
}

// Helper function to create entity record
const createEntityRecord = async (
  entityType: EntityType,
  entityData: any,
  productAmount: number | string,
  remarks?: string
): Promise<number> => {
  const amountValue =
    typeof productAmount === "string"
      ? parseFloat(productAmount)
      : productAmount;

  switch (entityType) {
    case "simCard_id": {
      const data = entityData as SimCardData;
      const [record] = await db
        .insert(simCard)
        .values({
          activatedStatus: data.activatedStatus ?? false,
          simcardPlan: data.simcardPlan ?? null,
          simCardGivingDate: data.simCardGivingDate ?? null,
          simActivationDate: data.simActivationDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "airTicket_id": {
      const data = entityData as AirTicketData;
      const [record] = await db
        .insert(airTicket)
        .values({
          isTicketBooked: data.isTicketBooked ?? false,
          amount: data.amount ? data.amount.toString() : amountValue.toString(),
          airTicket: data.airTicket ?? null,
          ticketDate: data.ticketDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "ielts_id": {
      const data = entityData as IeltsData;
      const [record] = await db
        .insert(ielts)
        .values({
          enrolledStatus: data.enrolledStatus ?? false,
          amount: data.amount.toString(),
          enrollmentDate: data.enrollmentDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "loan_id": {
      const data = entityData as LoanData;
      const [record] = await db
        .insert(loan)
        .values({
          amount: data.amount.toString(),
          disbursmentDate: data.disbursmentDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "forexCard_id": {
      const data = entityData as ForexCardData;
      const [record] = await db
        .insert(forexCard)
        .values({
          forexCardStatus: data.forexCardStatus ?? null,
          cardDate: data.cardDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "forexFees_id": {
      const data = entityData as ForexFeesData;
      if (!data.side || !["PI", "TP"].includes(data.side)) {
        throw new Error("side is required and must be 'PI' or 'TP'");
      }
      const [record] = await db
        .insert(forexFees)
        .values({
          side: data.side as any,
          amount: data.amount.toString(),
          feeDate: data.feeDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "tutionFees_id": {
      const data = entityData as TutionFeesData;
      if (
        !data.tutionFeesStatus ||
        !["paid", "pending"].includes(data.tutionFeesStatus)
      ) {
        throw new Error(
          "tutionFeesStatus is required and must be 'paid' or 'pending'"
        );
      }
      const [record] = await db
        .insert(tutionFees)
        .values({
          tutionFeesStatus: data.tutionFeesStatus as any,
          feeDate: data.feeDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "insurance_id": {
      const data = entityData as InsuranceData;
      const [record] = await db
        .insert(insurance)
        .values({
          amount: data.amount.toString(),
          insuranceDate: data.insuranceDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "beaconAccount_id": {
      const data = entityData as BeaconAccountData;
      const [record] = await db
        .insert(beaconAccount)
        .values({
          amount: data.amount.toString(),
          accountDate: data.accountDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "creditCard_id": {
      const data = entityData as CreditCardData;
      const [record] = await db
        .insert(creditCard)
        .values({
          amount: data.amount.toString(),
          cardDate: data.cardDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "visaextension_id": {
      const data = entityData as VisaExtensionData;
      if (!data.type) {
        throw new Error("type is required for visa extension");
      }
      const [record] = await db
        .insert(visaExtension)
        .values({
          type: data.type,
          amount: data.amount.toString(),
          extensionDate: data.extensionDate ?? null,
          invoiceNo: data.invoiceNo ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    case "newSell_id": {
      const data = entityData as NewSellData;
      if (!data.serviceName) {
        throw new Error("serviceName is required for new sell");
      }
      const [record] = await db
        .insert(newSell)
        .values({
          serviceName: data.serviceName,
          serviceInformation: data.serviceInformation ?? null,
          amount: data.amount.toString(),
          sellDate: data.sellDate ?? null,
          remarks: remarks ?? null,
        })
        .returning();
      return record.id;
    }

    default:
      throw new Error(`Unsupported entity type: ${entityType}`);
  }
};

// export const createClientProductPayment = async (
//   data: CreateClientProductPaymentInput
// ) => {
//   const { clientId, productName, amount, paymentDate, remarks, entityData } =
//     data;

//   // Validation
//   if (!clientId || !productName) {
//     throw new Error("clientId and productName are required");
//   }

//   const amountValue = typeof amount === "string" ? parseFloat(amount) : amount;
//   if (!amountValue || amountValue <= 0 || !isFinite(amountValue)) {
//     throw new Error("Amount must be a valid number greater than zero");
//   }

//   // Validate product name is valid enum value
//   const validProductNames: ProductType[] = [
//     "ALL_FINANCE_EMPLOYEMENT",
//     "INDIAN_SIDE_EMPLOYEMENT",
//     "NOC_LEVEL_JOB_ARRANGEMENT",
//     "LAWYER_REFUSAL_CHARGE",
//     "ONSHORE_PART_TIME_EMPLOYEMENT",
//     "TRV_WORK_PERMIT_EXT_STUDY_PERMIT_EXTENSION",
//     "MARRIAGE_PHOTO_FOR_COURT_MARRIAGE",
//     "MARRIAGE_PHOTO_CERTIFICATE",
//     "RECENTE_MARRIAGE_RELATIONSHIP_AFFIDAVIT",
//     "JUDICAL_REVIEW_CHARGE",
//     "SIM_CARD_ACTIVATION",
//     "INSURANCE",
//     "BEACON_ACCOUNT",
//     "AIR_TICKET",
//     "OTHER_NEW_SELL",
//     "SPONSOR_CHARGES",
//     "FINANCE_EMPLOYEMENT",
//     "IELTS_ENROLLMENT",
//     "LOAN_DETAILS",
//     "FOREX_CARD",
//     "FOREX_FEES",
//     "TUTION_FEES",
//     "CREDIT_CARD",
//     "VISA_EXTENSION",
//   ];

//   if (!validProductNames.includes(productName)) {
//     throw new Error(`Invalid productName: ${productName}`);
//   }

//   // Validate client exists
//   const [client] = await db
//     .select({ clientId: clientInformation.clientId })
//     .from(clientInformation)
//     .where(eq(clientInformation.clientId, clientId))
//     .limit(1);

//   if (!client) {
//     throw new Error("Client not found");
//   }

//   // Get entity type from product name
//   const entityType = productToEntityTypeMap[productName];
//   if (!entityType) {
//     throw new Error(`No entity type mapping found for product: ${productName}`);
//   }

//   // Validate payment date format if provided
//   if (paymentDate) {
//     const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
//     if (!dateRegex.test(paymentDate)) {
//       throw new Error("paymentDate must be in YYYY-MM-DD format");
//     }
//     const dateObj = new Date(paymentDate);
//     if (isNaN(dateObj.getTime())) {
//       throw new Error("Invalid paymentDate");
//     }
//   }

//   // Create entity record first and get its ID
//   let entityId: number;
//   if (entityData) {
//     entityId = await createEntityRecord(entityType, entityData, amountValue, remarks);
//   } else {
//     // If no entity data provided, create a minimal record in newSell
//     if (entityType === "newSell_id") {
//       entityId = await createEntityRecord(
//         "newSell_id",
//         {
//           serviceName: productName,
//           amount: amountValue,
//         },
//         amountValue,
//         remarks
//       );
//     } else {
//       throw new Error(
//         `entityData is required for product type: ${productName}`
//       );
//     }
//   }

//   // Insert the product payment
//   const [record] = await db
//     .insert(clientProductPayments)
//     .values({
//       clientId,
//       productName: productName as any,
//       amount: amountValue.toString(),
//       paymentDate: paymentDate ?? null,
//       entityId,
//       entityType: entityType as any,
//       remarks: remarks ?? null,
//     })
//     .returning();

//   return record;
// };

export const saveClientProductPayment = async (
  data: SaveClientProductPaymentInput
) => {
  const {
    productPaymentId,
    clientId,
    productName,
    invoiceNo,
    amount,
    paymentDate,
    remarks,
    entityData,
  } = data;

  if (!clientId || !productName) {
    throw new Error("clientId, productName and amount are required");
  }

  // const amountValue = typeof amount === "string" ? parseFloat(amount) : amount;
  // if (!isFinite(amountValue) || amountValue <= 0) {
  //   throw new Error("Amount must be a valid number greater than zero");
  // }

  let amountValue: number | null = null;

  if (amount !== undefined && amount !== null) {
    amountValue = typeof amount === "string" ? parseFloat(amount) : amount;

    if (!isFinite(amountValue) || amountValue <= 0) {
      throw new Error("Amount must be a valid number greater than zero");
    }
  }

  // Validate client exists
  const [client] = await db
    .select({ clientId: clientInformation.clientId })
    .from(clientInformation)
    .where(eq(clientInformation.clientId, clientId))
    .limit(1);

  if (!client) {
    throw new Error("Client not found");
  }

  // Validate productName
  if (!productToEntityTypeMap[productName]) {
    throw new Error(`Invalid productName: ${productName}`);
  }

  const entityType = productToEntityTypeMap[productName];

  // Validate paymentDate
  if (paymentDate) {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (
      !dateRegex.test(paymentDate) ||
      isNaN(new Date(paymentDate).getTime())
    ) {
      throw new Error("paymentDate must be valid YYYY-MM-DD");
    }
  }

  // =========================
  // UPDATE FLOW
  // =========================
  if (productPaymentId) {
    const [existingPayment] = await db
      .select()
      .from(clientProductPayments)
      .where(eq(clientProductPayments.productPaymentId, productPaymentId));

    if (!existingPayment) {
      throw new Error("Product payment record not found");
    }

    // Update entity if entityData provided
    let entityId = existingPayment.entityId;
    if (entityData) {
      const entityTable = entityTypeToTable[entityType];
      await db
        .update(entityTable)
        .set({ ...entityData, remarks: remarks ?? existingPayment.remarks })
        .where(eq(entityTable.id, entityId));
    }

    // Update payment record
    const [updatedPayment] = await db
      .update(clientProductPayments)
      .set({
        clientId,
        productName: productName as any,
        amount: amountValue !== null ? amountValue.toString() : existingPayment.amount,
        invoiceNo: (entityData as any)?.invoiceNo ?? existingPayment.invoiceNo,
        paymentDate: paymentDate ?? existingPayment.paymentDate,
        remarks: remarks ?? existingPayment.remarks,
      })
      .where(eq(clientProductPayments.productPaymentId, productPaymentId))
      .returning();

    return {
      action: "UPDATED",
      record: updatedPayment,
    };
  }

  // =========================
  // CREATE FLOW
  // =========================
  // Create entity record first
let entityId: number;

if (entityType === "newSell_id") {
  // ✅ MASTER TABLE ONLY
  if (!data.entityId) {
    throw new Error("entityId is required for newSell products");
  }

  // Optional: validate master record exists
  const [master] = await db
    .select({ id: newSell.id })
    .from(newSell)
    .where(eq(newSell.id, data.entityId))
    .limit(1);

  if (!master) {
    throw new Error("Invalid newSell master entityId");
  }

  entityId = data.entityId;

} else {
  // ✅ DYNAMIC ENTITY TABLES
  if (!entityData) {
    throw new Error(`entityData is required for product: ${productName}`);
  }

  entityId = await createEntityRecord(
    entityType,
    entityData,
    amountValue ?? 0,
    remarks
  );
}

// if (entityData && entityType !== "newSell_id") {
//   const entityTable = entityTypeToTable[entityType];
//   await db
//     .update(entityTable)
//     .set({ ...entityData, remarks: remarks ?? existingPayment.remarks })
//     .where(eq(entityTable.id, entityId));
// }

  // Insert client product payment
  const [record] = await db
    .insert(clientProductPayments)
    .values({
      clientId,
      productName: productName as any,
      amount: amountValue !== null ? amountValue.toString() : null,
      paymentDate: paymentDate ?? null,
      invoiceNo: invoiceNo ?? null,
      entityId,
      entityType: entityType as any,
      remarks: remarks ?? null,
    })
    .returning();

  return {
    action: "CREATED",
    record,
  };
};

export const getProductPaymentsByClientId = async (clientId: number) => {
  if (!clientId || clientId <= 0) {
    throw new Error("Valid clientId is required");
  }

  return db
    .select()
    .from(clientProductPayments)
    .where(eq(clientProductPayments.clientId, clientId));
};
