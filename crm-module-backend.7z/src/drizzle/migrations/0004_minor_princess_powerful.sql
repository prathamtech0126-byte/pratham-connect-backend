CREATE TYPE "public"."entity_type_enum" AS ENUM('visaextension_id', 'simCard_id', 'airTicket_id', 'newSell_id', 'ielts_id', 'loan_id', 'forexCard_id', 'forexFees_id', 'tutionFees_id', 'insurance_id', 'beaconAccount_id', 'creditCard_id');--> statement-breakpoint
CREATE TYPE "public"."product_type_enum" AS ENUM('ALL_FINANCE_EMPLOYEMENT', 'INDIAN_SIDE_EMPLOYEMENT', 'NOC_LEVEL_JOB_ARRANGEMENT', 'LAWYER_REFUSAL_CHARGE', 'ONSHORE_PART_TIME_EMPLOYEMENT', 'TRV_WORK_PERMIT_EXT_STUDY_PERMIT_EXTENSION', 'MARRIAGE_PHOTO_FOR_COURT_MARRIAGE', 'MARRIAGE_PHOTO_CERTIFICATE', 'RECENTE_MARRIAGE_RELATIONSHIP_AFFIDAVIT', 'JUDICAL_REVIEW_CHARGE', 'SIM_CARD_ACTIVATION', 'INSURANCE', 'BEACON_ACCOUNT', 'AIR_TICKET', 'OTHER_NEW_SELL', 'SPONSOR_CHARGES', 'FINANCE_EMPLOYEMENT', 'IELTS_ENROLLMENT', 'LOAN_DETAILS', 'FOREX_CARD', 'FOREX_FEES', 'TUTION_FEES', 'CREDIT_CARD', 'VISA_EXTENSION');--> statement-breakpoint
CREATE TYPE "public"."forex_side_enum" AS ENUM('PI', 'TP');--> statement-breakpoint
CREATE TYPE "public"."tution_fees_status_enum" AS ENUM('paid', 'pending');--> statement-breakpoint
CREATE TABLE "air_ticket" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"is_ticket_booked" boolean DEFAULT false,
	"amount" numeric(12, 2),
	"invoice_no" varchar(50),
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "beacon_account" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "credit_card" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "forex_card" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"forex_card_status" varchar(100),
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "forex_fees" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"side" "forex_side_enum" NOT NULL,
	"date" date,
	"amount" numeric(12, 2) NOT NULL,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ielts" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"enrolled_status" boolean DEFAULT false,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "insurance" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "loan" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"disbursment_date" date,
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "new_sell" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"service_name" varchar(150) NOT NULL,
	"service_information" text,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sim_card" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"activated_status" boolean DEFAULT false,
	"simcard_plan" varchar(100),
	"sim_card_giving_date" date,
	"sim_activation_date" date,
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "tution_fees" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"tution_fees_status" "tution_fees_status_enum" NOT NULL,
	"date" date,
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "visa_extension" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"type" varchar(100) NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"date" date,
	"invoice_no" varchar(50),
	"remark" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
DROP INDEX "idx_product_payment_status";--> statement-breakpoint
DROP INDEX "idx_product_payment_status_delivery";--> statement-breakpoint
DROP INDEX "idx_product_payment_status_install";--> statement-breakpoint
DROP INDEX "idx_product_payment_date";--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "product_name" SET DATA TYPE "public"."product_type_enum" USING "product_name"::"public"."product_type_enum";--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD COLUMN "date" date;--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD COLUMN "entity_id" bigint NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD COLUMN "entity_type" "entity_type_enum" NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD COLUMN "remark" text;--> statement-breakpoint
CREATE INDEX "idx_air_ticket_booked" ON "air_ticket" USING btree ("is_ticket_booked");--> statement-breakpoint
CREATE INDEX "idx_air_ticket_date" ON "air_ticket" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_air_ticket_created_at" ON "air_ticket" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_beacon_account_date" ON "beacon_account" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_beacon_account_created_at" ON "beacon_account" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_credit_card_date" ON "credit_card" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_credit_card_created_at" ON "credit_card" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_forex_card_status" ON "forex_card" USING btree ("forex_card_status");--> statement-breakpoint
CREATE INDEX "idx_forex_card_date" ON "forex_card" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_forex_card_created_at" ON "forex_card" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_forex_fees_side" ON "forex_fees" USING btree ("side");--> statement-breakpoint
CREATE INDEX "idx_forex_fees_date" ON "forex_fees" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_forex_fees_created_at" ON "forex_fees" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_ielts_enrolled_status" ON "ielts" USING btree ("enrolled_status");--> statement-breakpoint
CREATE INDEX "idx_ielts_date" ON "ielts" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_ielts_created_at" ON "ielts" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_insurance_date" ON "insurance" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_insurance_created_at" ON "insurance" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_loan_disbursment_date" ON "loan" USING btree ("disbursment_date");--> statement-breakpoint
CREATE INDEX "idx_loan_created_at" ON "loan" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_new_sell_service_name" ON "new_sell" USING btree ("service_name");--> statement-breakpoint
CREATE INDEX "idx_new_sell_date" ON "new_sell" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_new_sell_created_at" ON "new_sell" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_sim_card_activated_status" ON "sim_card" USING btree ("activated_status");--> statement-breakpoint
CREATE INDEX "idx_sim_card_giving_date" ON "sim_card" USING btree ("sim_card_giving_date");--> statement-breakpoint
CREATE INDEX "idx_sim_card_created_at" ON "sim_card" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_tution_fees_status" ON "tution_fees" USING btree ("tution_fees_status");--> statement-breakpoint
CREATE INDEX "idx_tution_fees_date" ON "tution_fees" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_tution_fees_created_at" ON "tution_fees" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_visa_extension_date" ON "visa_extension" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_visa_extension_created_at" ON "visa_extension" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_product_payment_product_name" ON "client_product_payment" USING btree ("product_name");--> statement-breakpoint
CREATE INDEX "idx_product_payment_entity" ON "client_product_payment" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "idx_product_payment_client_product" ON "client_product_payment" USING btree ("client_id","product_name");--> statement-breakpoint
CREATE INDEX "idx_product_payment_date" ON "client_product_payment" USING btree ("date");--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "payment_date";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "invoice_no";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "product_status";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "product_information";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "date_of_delivery";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "date_of_installation";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP COLUMN "remarks";