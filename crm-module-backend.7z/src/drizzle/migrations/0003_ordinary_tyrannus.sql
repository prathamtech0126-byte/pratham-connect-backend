CREATE TABLE "activity_log" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"entity_type" varchar(50) NOT NULL,
	"entity_id" bigint NOT NULL,
	"action" varchar(50) NOT NULL,
	"old_value" jsonb,
	"new_value" jsonb,
	"performed_by" bigint,
	"ip_address" varchar(45),
	"user_agent" varchar(255),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "activity_log" ADD CONSTRAINT "activity_log_performed_by_users_id_fk" FOREIGN KEY ("performed_by") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_activity_entity" ON "activity_log" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "idx_activity_action" ON "activity_log" USING btree ("action");--> statement-breakpoint
CREATE INDEX "idx_activity_user" ON "activity_log" USING btree ("performed_by");--> statement-breakpoint
CREATE INDEX "idx_activity_created_at" ON "activity_log" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_client_counsellor" ON "client_information" USING btree ("counsellor_id");--> statement-breakpoint
CREATE INDEX "idx_client_sale_type" ON "client_information" USING btree ("sale_type_id");--> statement-breakpoint
CREATE INDEX "idx_client_enrollment_date" ON "client_information" USING btree ("date");--> statement-breakpoint
CREATE INDEX "idx_client_created_at" ON "client_information" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_client_counsellor_created" ON "client_information" USING btree ("counsellor_id","created_at");--> statement-breakpoint
CREATE INDEX "idx_payment_client" ON "client_payment" USING btree ("client_id");--> statement-breakpoint
CREATE INDEX "idx_payment_stage" ON "client_payment" USING btree ("stage");--> statement-breakpoint
CREATE INDEX "idx_payment_date" ON "client_payment" USING btree ("payment_date");--> statement-breakpoint
CREATE INDEX "idx_payment_created_at" ON "client_payment" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_payment_client_date" ON "client_payment" USING btree ("client_id","payment_date");--> statement-breakpoint
CREATE INDEX "idx_payment_client_stage" ON "client_payment" USING btree ("client_id","stage");--> statement-breakpoint
CREATE INDEX "idx_payment_stage_date" ON "client_payment" USING btree ("stage","payment_date");--> statement-breakpoint
CREATE INDEX "idx_product_payment_client" ON "client_product_payment" USING btree ("client_id");--> statement-breakpoint
CREATE INDEX "idx_product_payment_status" ON "client_product_payment" USING btree ("product_status");--> statement-breakpoint
CREATE INDEX "idx_product_payment_date" ON "client_product_payment" USING btree ("payment_date");--> statement-breakpoint
CREATE INDEX "idx_product_payment_created_at" ON "client_product_payment" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_product_payment_client_created" ON "client_product_payment" USING btree ("client_id","created_at");--> statement-breakpoint
CREATE INDEX "idx_product_payment_status_delivery" ON "client_product_payment" USING btree ("product_status","date_of_delivery");--> statement-breakpoint
CREATE INDEX "idx_product_payment_status_install" ON "client_product_payment" USING btree ("product_status","date_of_installation");--> statement-breakpoint
CREATE INDEX "idx_sale_type_core" ON "sale_type" USING btree ("is_core_product");--> statement-breakpoint
CREATE INDEX "idx_sale_type_created_at" ON "sale_type" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_sale_type_core_created" ON "sale_type" USING btree ("is_core_product","created_at");