import { Request, Response } from "express";
import {
  createUser,
  getAllUsers,
  updateUserByAdmin,
  deleteUserByAdmin,
  getAllManagers,
} from "../models/user.model";
import bcrypt from "bcrypt";
import { db } from "../config/databaseConnection";
import { users } from "../schemas/users.schema";
import { refreshTokens } from "../schemas/refreshToken.schema";
import {
  generateAccessToken,
  generateRefreshToken,
  hashToken,
} from "../utils/token";
import { eq } from "drizzle-orm";
import jwt from "jsonwebtoken";
import { Role } from "../types/role";
import { AuthenticatedRequest } from "./../@types/express/auth";
import { off } from "node:cluster";
/* ================================
   REGISTER
================================ */

export const registerUser = async (req: Request, res: Response) => {
  try {
    const authReq = req as AuthenticatedRequest;

    // normalize input: accept snake_case or variants from clients
    const body = req.body || {};
    // normalize managerId: accept numeric strings, null/empty => undefined
    const managerRaw = body.managerId ?? body.manager_id;
    let managerId: number | undefined = undefined;
    if (managerRaw !== undefined && managerRaw !== null && managerRaw !== "") {
      const parsed = Number(managerRaw);
      if (!Number.isFinite(parsed) || isNaN(parsed)) {
        return res.status(400).json({ message: "managerId must be a valid number" });
      }
      managerId = parsed;
    }

    const payload = {
      fullName: body.fullName ?? body.full_name,
      email: body.email ? body.email.toLowerCase().trim() : undefined,
      password: body.password,
      role: body.role,
      empId: body.empId ?? body.emp_id,
      managerId,
      officePhone:
        body.officePhone ??
        body.office_phone ??
        body.company_phone_no ??
        body.office_phone_no,
      personalPhone:
        body.personalPhone ?? body.personal_phone ?? body.personal_phone_no,
      designation: body.designation,
    };

    try {
      const user = await createUser(payload as any, authReq.user.role);
      res.status(201).json(user);
    } catch (error: any) {
      // map common DB or validation errors to 400
      return res.status(400).json({ message: error?.message ?? String(error) });
    }
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
};

/* ================================
   LOGIN
================================ */

export const login = async (req: Request, res: Response) => {
  const { email, password } = req.body;
  const emailNormalized = email ? String(email).toLowerCase().trim() : email;

  if (!email || !password) {
    return res
      .status(400)
      .json({ message: "username and password are required" });
  }

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, emailNormalized));

  if (!user) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const isMatch = await bcrypt.compare(password, user.passwordHash);
  if (!isMatch) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  // revoke all previous refresh tokens (ensures single-device session)
  await db
    .update(refreshTokens)
    .set({ revoked: true })
    .where(eq(refreshTokens.userId, user.id));

  // create a new refresh token and store its hash
  const refreshToken = generateRefreshToken({ userId: user.id });

  const [inserted] = await db
    .insert(refreshTokens)
    .values({
      userId: user.id,
      tokenHash: hashToken(refreshToken),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    })
    .returning({ id: refreshTokens.id });

  const sessionId = inserted.id;

  // generate access token tied to this session id
  const accessToken = generateAccessToken({
    userId: user.id,
    role: user.role as Role,
    sessionId,
  });

  // set cookies (access short lived, refresh long lived)
  res.cookie("accessToken", accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "none",
    maxAge: 15 * 60 * 1000,
  });

  res.cookie("refreshToken", refreshToken, {
    httpOnly: true,
    secure: true,
    sameSite: "none",
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  res.json({
    message: "Login successful",
    fullname: user.fullName,
    email: user.email,
    empid: user.emp_id,
    officePhone: user.officePhone,
    personalPhone: user.personalPhone,
    designation: user.designation,
    role: user.role,
    accessToken,
  });
};

/* ================================
   REFRESH TOKEN
================================ */

export const refreshAccessToken = async (req: Request, res: Response) => {
  const refreshToken = req.cookies.refreshToken;

  if (!refreshToken) {
    return res.status(401).json({ message: "Refresh token missing" });
  }

  try {
    const decoded = jwt.verify(
      refreshToken,
      process.env.JWT_REFRESH_SECRET!
    ) as { userId: number };

    const [storedToken] = await db
      .select()
      .from(refreshTokens)
      .where(eq(refreshTokens.tokenHash, hashToken(refreshToken)));

    if (!storedToken || storedToken.revoked) {
      return res.status(401).json({ message: "Session expired" });
    }

    // load the user's current role from the database instead of relying on req.user
    const [dbUser] = await db
      .select()
      .from(users)
      .where(eq(users.id, decoded.userId));

    if (!dbUser) {
      return res.status(401).json({ message: "User not found" });
    }

    const newAccessToken = generateAccessToken({
      userId: decoded.userId,
      role: dbUser.role as Role,
      sessionId: storedToken.id,
    });

    // res.cookie("accessToken", newAccessToken, {
    //   httpOnly: true,
    //   secure: process.env.NODE_ENV === "production",
    //   sameSite: "lax",
    //   maxAge: 15 * 60 * 1000,
    // });

    res.cookie("accessToken", newAccessToken, {
      httpOnly: true,
      secure: true,
      sameSite: "none",
      maxAge: 15 * 60 * 1000,
    });

    res.json({
      message: "Token refreshed",
      accessToken: newAccessToken,
      role: dbUser.role,
    });
  } catch {
    res.status(401).json({ message: "Invalid refresh token" });
  }
};

/* ================================
   LOGOUT
================================ */

export const logout = async (req: Request, res: Response) => {
  const refreshToken = req.cookies.refreshToken;

  if (refreshToken) {
    try {
      await db
        .update(refreshTokens)
        .set({ revoked: true })
        .where(eq(refreshTokens.tokenHash, hashToken(refreshToken)));
    } catch (err) {
      // log and continue
      console.error("Failed to revoke refresh token on logout", err);
    }
  }

  res.clearCookie("accessToken");
  res.clearCookie("refreshToken");
  res.json({ message: "Logged out successfully" });
};

/* ================================
   ADMIN CONTROLLERS
================================ */

export const getAllUsersController = async (_req: Request, res: Response) => {
  const users = await getAllUsers();
  res.json({ success: true, count: users.length, data: users });
};

export const updateUserController = async (req: Request, res: Response) => {
  const userId = Number(req.params.userId);

  const body = req.body || {};

  // normalize managerId: accept numeric strings, null/empty => undefined
  const managerRaw = body.managerId ?? body.manager_id;
  let managerId: number | undefined = undefined;
  if (managerRaw !== undefined && managerRaw !== null && managerRaw !== "") {
    const parsed = Number(managerRaw);
    if (!Number.isFinite(parsed) || isNaN(parsed)) {
      return res.status(400).json({ message: "managerId must be a valid number" });
    }
    managerId = parsed;
  }

  const payload = {
    fullName: body.fullName ?? body.full_name,
    email: body.email ? body.email.toLowerCase().trim() : undefined,
    password: body.password,
    role: body.role,
    empId: body.empId ?? body.emp_id,
    managerId,
    officePhone:
      body.officePhone ??
      body.office_phone ??
      body.company_phone_no ??
      body.office_phone_no,
    personalPhone:
      body.personalPhone ?? body.personal_phone ?? body.personal_phone_no,
    designation: body.designation,
  };

  try {
    const updatedUser = await updateUserByAdmin(userId, payload as any);
    res.json({ success: true, data: updatedUser });
  } catch (error: any) {
    // Validation and uniqueness errors are returned as 400
    res
      .status(400)
      .json({ success: false, message: error?.message ?? String(error) });
  }
};

export const deleteUserController = async (req: Request, res: Response) => {
  const targetUserId = Number(req.params.userId);
  const adminUserId = (req as AuthenticatedRequest).user.id;

  const result = await deleteUserByAdmin(targetUserId, adminUserId);
  res.json({ success: true, message: result.message });
};

export const getManagersDropdown = async (_req: Request, res: Response) => {
  const managers = await getAllManagers();
  res.json({ success: true, count: managers.length, data: managers });
};
