import { Request, Response } from "express";
import {
  saveClientProductPayment,
  getProductPaymentsByClientId,
  ProductType,
} from "../models/clientProductPayments.model";

// export const createClientProductPaymentController = async (
//   req: Request,
//   res: Response
// ) => {
//   try {
//     const body = req.body || {};

//     // Validate required fields
//     if (!body.clientId) {
//       return res.status(400).json({
//         success: false,
//         message: "clientId is required",
//       });
//     }

//     if (!body.productName) {
//       return res.status(400).json({
//         success: false,
//         message: "productName is required",
//       });
//     }

//     if (!body.amount) {
//       return res.status(400).json({
//         success: false,
//         message: "amount is required",
//       });
//     }

//     // Normalize and validate input
//     const payload = {
//       clientId: Number(body.clientId),
//       productName: body.productName as ProductType,
//       amount: body.amount,
//       paymentDate: body.paymentDate || body.payment_date,
//       remarks: body.remarks || body.remark,
//       entityData: body.entityData || body.entity_data,
//     };

//     // Validate clientId is a valid number
//     if (!Number.isFinite(payload.clientId) || payload.clientId <= 0) {
//       return res.status(400).json({
//         success: false,
//         message: "clientId must be a valid positive number",
//       });
//     }

//     const record = await createClientProductPayment(payload);

//     res.status(201).json({
//       success: true,
//       data: record,
//     });
//   } catch (error: any) {
//     res.status(400).json({
//       success: false,
//       message: error.message || "Failed to create product payment",
//     });
//   }
// };


export const saveClientProductPaymentController = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await saveClientProductPayment(req.body);

    res.status(200).json({
      success: true,
      action: result.action,
      data: result.record,
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

export const getClientProductPaymentsController = async (
  req: Request,
  res: Response
) => {
  try {
    const clientId = Number(req.params.clientId);

    if (!Number.isFinite(clientId) || clientId <= 0) {
      return res.status(400).json({
        success: false,
        message: "Valid clientId is required",
      });
    }

    const records = await getProductPaymentsByClientId(clientId);

    res.json({
      success: true,
      count: records.length,
      data: records,
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message || "Failed to fetch product payments",
    });
  }
};
