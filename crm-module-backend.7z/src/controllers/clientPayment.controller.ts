import { Request, Response } from "express";
import {
  saveClientPayment,
  getPaymentsByClientId,
} from "../models/clientPayment.model";

/**
 * Create client payment
 */
export const saveClientPaymentController = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await saveClientPayment(req.body);

    res.status(200).json({
      success: true,
      action: result.action,
      data: result.payment,
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

/**
 * Get payments by client id
 */
export const getClientPaymentsController = async (
  req: Request,
  res: Response
) => {
  try {
    const clientId = Number(req.params.clientId);

    if (Number.isNaN(clientId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid clientId",
      });
    }

    const payments = await getPaymentsByClientId(clientId);

    res.status(200).json({
      success: true,
      count: payments.length,
      data: payments,
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};
