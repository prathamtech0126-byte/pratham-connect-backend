import { Request, Response } from "express";
import { saveClient, getClientFullDetailsById } from "../models/client.model";

/* ==============================
   CREATE CLIENT
============================== */
// export const createClientController = async (
//   req: Request,
//   res: Response
// ) => {
//   try {
//     const client = await createClient(req.body);

//     res.status(201).json({
//       success: true,
//       data: client,
//     });
//   } catch (error: any) {
//     res.status(400).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };
export const saveClientController = async (req: Request, res: Response) => {
  try {
    if (!req.user?.id) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const client = await saveClient(req.body, req.user.id);

    res.status(200).json({
      success: true,
      data: client,
    });
  } catch (error: any) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};




export const getClientFullDetailsController = async (req: Request, res: Response) => {
  try {
    const clientId = Number(req.params.clientId);

    if (!clientId) {
      return res.status(400).json({ message: "Client ID is required" });
    }

    const data = await getClientFullDetailsById(clientId);

    if (!data) {
      return res.status(404).json({ message: "Client not found" });
    }

    return res.status(200).json({
      success: true,
      data,
    });
  } catch (error) {
    console.error("Get client full details error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};