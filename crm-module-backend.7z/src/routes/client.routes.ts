import { Router } from "express";
import { saveClientController, getClientFullDetailsController } from "../controllers/client.controller";
import { requireAuth, requireRole } from "../middlewares/auth.middleware";

const router = Router();

/**
 * Counsellor / Admin can create client
 */
router.post(
  "/",
  requireAuth,
  requireRole("admin", "counsellor", "manager"),
  saveClientController
);

/**
 * Get client full details by ID
 */
router.get(
  "/:clientId",
  requireAuth, requireRole("admin", "counsellor", "manager"),
  getClientFullDetailsController
);

export default router;
