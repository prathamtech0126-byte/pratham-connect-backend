import { Router } from "express";
import { registerUser,login,logout,refreshAccessToken,getAllUsersController,updateUserController, deleteUserController, getManagersDropdown } from "../controllers/user.controller";
import { requireAuth,requireRole } from "../middlewares/auth.middleware";
import { healthController } from "../controllers/health.controller";

const router = Router();

router.post("/login", login);
router.post("/refresh", refreshAccessToken);
router.post("/logout", requireAuth,logout);

// 🔐 ADMIN ONLY: Get all users
router.post("/register",requireAuth,requireRole("admin"), registerUser);
router.get("/users",requireAuth,requireRole("admin"),getAllUsersController);
router.put("/users-update/:userId",requireAuth,requireRole("admin"),updateUserController);
router.delete("/users-delete/:userId",requireAuth,requireRole("admin"),deleteUserController);
/**
 * Managers dropdown (admin only)
 */
router.get("/managers",requireAuth, requireRole("admin"),getManagersDropdown);

// health check alias under /api/users
router.get("/health", healthController);

// /api/users/users-delete/:userId

// export the router
export default router;