import { Router } from "express";
import {
  createSaleTypeController,
  getSaleTypesController,
  updateSaleTypeController,
  deleteSaleTypeController,
} from "../controllers/saleType.controller";
import { requireAuth, requireRole } from "../middlewares/auth.middleware";

const router = Router();

/**
 * Admin only
 */
router.post("/", requireAuth, requireRole("admin"), createSaleTypeController);
router.get("/", requireAuth, getSaleTypesController);
router.put("/:id", requireAuth, requireRole("admin"), updateSaleTypeController);
router.delete("/:id", requireAuth, requireRole("admin"), deleteSaleTypeController);

export default router;
