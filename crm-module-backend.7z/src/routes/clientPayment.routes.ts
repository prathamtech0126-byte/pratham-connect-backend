import { Router } from "express";
import {
  saveClientPaymentController,
  getClientPaymentsController,
} from "../controllers/clientPayment.controller";
import { requireAuth, requireRole } from "../middlewares/auth.middleware";

const router = Router();

/**
 * Create payment (Admin / Counsellor)
 */
router.post("/", requireAuth, requireRole("admin", "counsellor","manager"), saveClientPaymentController);

/**
 * Get payments by client
 */
router.get(
  "/client/:clientId",
  requireAuth,
  getClientPaymentsController
);

export default router;
