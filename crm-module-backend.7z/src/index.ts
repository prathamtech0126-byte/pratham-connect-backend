import express, { Application } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import userRoutes from "./routes/user.routes";
import saleRoute from "./routes/saleType.routes";
import clientRoute from "./routes/client.routes";
import clientPaymentRoutes from "./routes/clientPayment.routes";
import clientProductPaymentRoutes from "./routes/clientProductPayment.routes";
import { healthController } from "./controllers/health.controller";

const app: Application = express();

const allowedOrigins = [
  process.env.FRONTEND_URL ?? "https://5351ddd4-980f-4b3b-a8a8-cdc1176398ed-00-14w4lt4y9xf89.sisko.replit.dev/",
];
// ✅ CORS MUST be FIRST middleware
app.use(
  cors({
    origin: (origin, callback) => {
      // allow requests with no origin (e.g., curl, mobile, server-to-server)
      if (!origin) return callback(null, true);

      // allow local dev by default
      if (process.env.NODE_ENV !== "production") return callback(null, true);

      // explicit allowlist
      if (allowedOrigins.includes(origin)) return callback(null, true);

      // allow Replit host patterns (sisko.replit.dev) used by frontends
      if (origin.includes("sisko.replit.dev")) return callback(null, true);

      // allow localhost variants when running in prod behind a known host (optional)
      if (origin.startsWith("http://localhost") || origin.startsWith("http://127.0.0.1")) {
        return callback(null, true);
      }

      callback(new Error("CORS policy: origin not allowed"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    optionsSuccessStatus: 200, // ✅ ADD THIS
  })
);


app.use(express.json());
app.use(cookieParser());

//"C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel --url http://localhost:5000


// lightweight health check
app.get("/health", healthController);
app.use("/api/users", userRoutes);
app.use("/api/sale-types", saleRoute);
app.use("/api/clients", clientRoute);
app.use("/api/client-payments", clientPaymentRoutes);
app.use("/api/client-product-payments", clientProductPaymentRoutes);

export default app;
