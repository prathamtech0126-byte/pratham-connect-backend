ALTER TABLE "client_payment" ALTER COLUMN "payment_date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "invoice_no" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ADD CONSTRAINT "client_payment_invoice_no_unique" UNIQUE("invoice_no");