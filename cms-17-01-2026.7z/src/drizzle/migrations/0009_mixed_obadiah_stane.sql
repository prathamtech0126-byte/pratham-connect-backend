DROP INDEX "idx_beacon_account_date";--> statement-breakpoint
ALTER TABLE "beacon_account" ADD COLUMN "opening_date" date;--> statement-breakpoint
ALTER TABLE "beacon_account" ADD COLUMN "funding_date" date;--> statement-breakpoint
CREATE INDEX "idx_beacon_account_opening_date" ON "beacon_account" USING btree ("opening_date");--> statement-breakpoint
CREATE INDEX "idx_beacon_account_funding_date" ON "beacon_account" USING btree ("funding_date");--> statement-breakpoint
ALTER TABLE "beacon_account" DROP COLUMN "date";