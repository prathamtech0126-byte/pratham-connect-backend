ALTER TABLE "client_information" ALTER COLUMN "counsellor_id" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "client_id" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "client_id" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "refresh_tokens" ALTER COLUMN "user_id" SET DATA TYPE bigint;--> statement-breakpoint
ALTER TABLE "sale_type" ADD COLUMN "is_core_product" boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE "sale_type" DROP COLUMN "is_product";