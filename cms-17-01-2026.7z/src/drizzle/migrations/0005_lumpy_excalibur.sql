ALTER TABLE "client_product_payment" ALTER COLUMN "amount" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ADD COLUMN "air_ticket" varchar(50);--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD COLUMN "invoice_no" varchar(50);--> statement-breakpoint
ALTER TABLE "air_ticket" DROP COLUMN "invoice_no";