CREATE TYPE "public"."stage_enum" AS ENUM('INITIAL', 'BEFORE_VISA', 'AFTER_VISA', 'SUBMITTED_VISA');--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "stage" SET DATA TYPE "public"."stage_enum" USING "stage"::"public"."stage_enum";--> statement-breakpoint
CREATE INDEX "idx_users_role" ON "users" USING btree ("role");--> statement-breakpoint
CREATE INDEX "idx_users_manager" ON "users" USING btree ("manager_id");--> statement-breakpoint
CREATE INDEX "idx_users_created_at" ON "users" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "idx_users_role_manager" ON "users" USING btree ("role","manager_id");