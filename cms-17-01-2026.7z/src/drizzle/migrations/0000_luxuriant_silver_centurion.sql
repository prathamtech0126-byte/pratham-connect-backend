CREATE TABLE "client_information" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"counsellor_id" bigserial NOT NULL,
	"fullname" varchar(150) NOT NULL,
	"date" date NOT NULL,
	"sale_type_id" serial NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "client_payment" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"client_id" bigserial NOT NULL,
	"total_payment" numeric(12, 2) NOT NULL,
	"stage" varchar(20) NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"payment_date" date,
	"invoice_no" varchar(50),
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "client_product_payment" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"client_id" bigserial NOT NULL,
	"product_name" varchar(100) NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"payment_date" date,
	"invoice_no" varchar(50),
	"product_status" varchar(50),
	"product_information" varchar(255),
	"date_of_delivery" date,
	"date_of_installation" date,
	"remarks" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "refresh_tokens" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"user_id" bigserial NOT NULL,
	"token_hash" varchar(255) NOT NULL,
	"expires_at" timestamp NOT NULL,
	"revoked" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sale_type" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"sale_type" varchar(100) NOT NULL,
	"amount" numeric(12, 2),
	"is_product" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "sale_type_sale_type_unique" UNIQUE("sale_type")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"emp_id" varchar(50),
	"full_name" varchar(100) NOT NULL,
	"email" varchar(150) NOT NULL,
	"password_hash" varchar(255) NOT NULL,
	"role" varchar(50) NOT NULL,
	"manager_id" bigint,
	"office_phone" varchar(10),
	"personal_phone" varchar(10),
	"designation" varchar(100),
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "users_emp_id_unique" UNIQUE("emp_id"),
	CONSTRAINT "users_email_unique" UNIQUE("email"),
	CONSTRAINT "users_office_phone_unique" UNIQUE("office_phone"),
	CONSTRAINT "users_personal_phone_unique" UNIQUE("personal_phone")
);
--> statement-breakpoint
ALTER TABLE "client_information" ADD CONSTRAINT "client_information_counsellor_id_users_id_fk" FOREIGN KEY ("counsellor_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "client_information" ADD CONSTRAINT "client_information_sale_type_id_sale_type_id_fk" FOREIGN KEY ("sale_type_id") REFERENCES "public"."sale_type"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "client_payment" ADD CONSTRAINT "client_payment_client_id_client_information_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."client_information"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD CONSTRAINT "client_product_payment_client_id_client_information_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."client_information"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_manager_id_users_id_fk" FOREIGN KEY ("manager_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;