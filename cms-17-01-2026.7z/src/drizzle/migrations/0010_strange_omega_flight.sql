ALTER TABLE "air_ticket" ADD COLUMN "air_ticket_number" varchar(50);--> statement-breakpoint
ALTER TABLE "insurance" ADD COLUMN "policy_number" varchar(50);--> statement-breakpoint
ALTER TABLE "air_ticket" DROP COLUMN "air_ticket";