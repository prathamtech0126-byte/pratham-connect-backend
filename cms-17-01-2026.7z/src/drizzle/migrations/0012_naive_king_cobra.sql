CREATE TABLE "lead_type" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"lead_type" varchar(100) NOT NULL,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "lead_type_lead_type_unique" UNIQUE("lead_type")
);
--> statement-breakpoint
ALTER TABLE "client_information" ADD COLUMN "lead_type_id" serial NOT NULL;--> statement-breakpoint
ALTER TABLE "client_information" ADD CONSTRAINT "client_information_lead_type_id_lead_type_id_fk" FOREIGN KEY ("lead_type_id") REFERENCES "public"."lead_type"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_client_lead_type" ON "client_information" USING btree ("lead_type_id");