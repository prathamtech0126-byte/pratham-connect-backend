ALTER TABLE "air_ticket" DROP CONSTRAINT "air_ticket_air_ticket_number_unique";--> statement-breakpoint
ALTER TABLE "client_payment" DROP CONSTRAINT "client_payment_invoice_no_unique";--> statement-breakpoint
ALTER TABLE "client_product_payment" DROP CONSTRAINT "client_product_payment_invoice_no_unique";--> statement-breakpoint
ALTER TABLE "insurance" DROP CONSTRAINT "insurance_policy_number_unique";--> statement-breakpoint
ALTER TABLE "new_sell" DROP CONSTRAINT "new_sell_invoice_no_unique";--> statement-breakpoint
ALTER TABLE "visa_extension" DROP CONSTRAINT "visa_extension_invoice_no_unique";--> statement-breakpoint
ALTER TABLE "air_ticket" ALTER COLUMN "amount" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ALTER COLUMN "air_ticket_number" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "payment_date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "invoice_no" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "credit_card" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_card" ALTER COLUMN "forex_card_status" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_card" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_fees" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "ielts" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "insurance" ALTER COLUMN "policy_number" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "insurance" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "loan" ALTER COLUMN "disbursment_date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "new_sell" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "new_sell" ALTER COLUMN "invoice_no" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "sim_card" ALTER COLUMN "simcard_plan" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "tution_fees" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "visa_extension" ALTER COLUMN "date" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "visa_extension" ALTER COLUMN "invoice_no" DROP NOT NULL;