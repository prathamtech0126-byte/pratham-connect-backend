-- Update NULL values and fix duplicates before setting NOT NULL constraints
UPDATE "air_ticket" SET "amount" = '0.00' WHERE "amount" IS NULL;--> statement-breakpoint
UPDATE "air_ticket" SET "air_ticket_number" = 'N/A-' || "id"::text WHERE "air_ticket_number" IS NULL;--> statement-breakpoint
-- Fix duplicate air_ticket_number
UPDATE "air_ticket" at1
SET "air_ticket_number" = at1."air_ticket_number" || '-DUP-' || at1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "air_ticket" at2
  WHERE at2."air_ticket_number" = at1."air_ticket_number"
  AND at2."id" < at1."id"
);--> statement-breakpoint
UPDATE "air_ticket" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "client_payment" SET "payment_date" = CURRENT_DATE WHERE "payment_date" IS NULL;--> statement-breakpoint
-- Fix duplicate invoice_no: Update all duplicates to be unique using id
-- First, update all invoice_no to be unique (handle both NULL and duplicates)
UPDATE "client_payment" SET "invoice_no" = 'INV-' || "id"::text WHERE "invoice_no" IS NULL;--> statement-breakpoint
-- Then fix any remaining duplicates by appending id to make them unique
UPDATE "client_payment" cp1
SET "invoice_no" = cp1."invoice_no" || '-DUP-' || cp1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "client_payment" cp2
  WHERE cp2."invoice_no" = cp1."invoice_no"
  AND cp2."id" < cp1."id"
);--> statement-breakpoint
UPDATE "client_product_payment" SET "amount" = '0.00' WHERE "amount" IS NULL;--> statement-breakpoint
UPDATE "client_product_payment" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
-- Fix duplicate invoice_no: Update all duplicates to be unique using id
UPDATE "client_product_payment" SET "invoice_no" = 'INV-PROD-' || "id"::text WHERE "invoice_no" IS NULL;--> statement-breakpoint
-- Then fix any remaining duplicates by appending id to make them unique
UPDATE "client_product_payment" cpp1
SET "invoice_no" = cpp1."invoice_no" || '-DUP-' || cpp1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "client_product_payment" cpp2
  WHERE cpp2."invoice_no" = cpp1."invoice_no"
  AND cpp2."id" < cpp1."id"
);--> statement-breakpoint
UPDATE "credit_card" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "forex_card" SET "forex_card_status" = 'pending' WHERE "forex_card_status" IS NULL;--> statement-breakpoint
UPDATE "forex_card" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "forex_fees" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "ielts" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "insurance" SET "policy_number" = 'POL-' || "id"::text WHERE "policy_number" IS NULL;--> statement-breakpoint
-- Fix duplicate policy_number
UPDATE "insurance" ins1
SET "policy_number" = ins1."policy_number" || '-DUP-' || ins1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "insurance" ins2
  WHERE ins2."policy_number" = ins1."policy_number"
  AND ins2."id" < ins1."id"
);--> statement-breakpoint
UPDATE "insurance" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "loan" SET "disbursment_date" = CURRENT_DATE WHERE "disbursment_date" IS NULL;--> statement-breakpoint
UPDATE "new_sell" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
-- Fix duplicate invoice_no: Update all duplicates to be unique using id
UPDATE "new_sell" SET "invoice_no" = 'INV-SELL-' || "id"::text WHERE "invoice_no" IS NULL;--> statement-breakpoint
-- Then fix any remaining duplicates by appending id to make them unique
UPDATE "new_sell" ns1
SET "invoice_no" = ns1."invoice_no" || '-DUP-' || ns1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "new_sell" ns2
  WHERE ns2."invoice_no" = ns1."invoice_no"
  AND ns2."id" < ns1."id"
);--> statement-breakpoint
UPDATE "sim_card" SET "simcard_plan" = 'default' WHERE "simcard_plan" IS NULL;--> statement-breakpoint
UPDATE "tution_fees" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
UPDATE "visa_extension" SET "date" = CURRENT_DATE WHERE "date" IS NULL;--> statement-breakpoint
-- Fix duplicate invoice_no: Update all duplicates to be unique using id
UPDATE "visa_extension" SET "invoice_no" = 'INV-VISA-' || "id"::text WHERE "invoice_no" IS NULL;--> statement-breakpoint
-- Then fix any remaining duplicates by appending id to make them unique
UPDATE "visa_extension" ve1
SET "invoice_no" = ve1."invoice_no" || '-DUP-' || ve1."id"::text
WHERE EXISTS (
  SELECT 1 FROM "visa_extension" ve2
  WHERE ve2."invoice_no" = ve1."invoice_no"
  AND ve2."id" < ve1."id"
);--> statement-breakpoint

-- Now apply NOT NULL constraints
ALTER TABLE "air_ticket" ALTER COLUMN "amount" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ALTER COLUMN "air_ticket_number" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "payment_date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_payment" ALTER COLUMN "invoice_no" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "amount" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "client_product_payment" ALTER COLUMN "invoice_no" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "credit_card" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_card" ALTER COLUMN "forex_card_status" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_card" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "forex_fees" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "ielts" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "insurance" ALTER COLUMN "policy_number" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "insurance" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "loan" ALTER COLUMN "disbursment_date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "new_sell" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "new_sell" ALTER COLUMN "invoice_no" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "sim_card" ALTER COLUMN "simcard_plan" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "tution_fees" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "visa_extension" ALTER COLUMN "date" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "visa_extension" ALTER COLUMN "invoice_no" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "air_ticket" ADD CONSTRAINT "air_ticket_air_ticket_number_unique" UNIQUE("air_ticket_number");--> statement-breakpoint
ALTER TABLE "client_payment" ADD CONSTRAINT "client_payment_invoice_no_unique" UNIQUE("invoice_no");--> statement-breakpoint
ALTER TABLE "client_product_payment" ADD CONSTRAINT "client_product_payment_invoice_no_unique" UNIQUE("invoice_no");--> statement-breakpoint
ALTER TABLE "insurance" ADD CONSTRAINT "insurance_policy_number_unique" UNIQUE("policy_number");--> statement-breakpoint
ALTER TABLE "new_sell" ADD CONSTRAINT "new_sell_invoice_no_unique" UNIQUE("invoice_no");--> statement-breakpoint
ALTER TABLE "visa_extension" ADD CONSTRAINT "visa_extension_invoice_no_unique" UNIQUE("invoice_no");