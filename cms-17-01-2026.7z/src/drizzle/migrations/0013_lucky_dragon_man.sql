CREATE TYPE "public"."activity_action_enum" AS ENUM('CREATE', 'UPDATE', 'DELETE', 'STATUS_CHANGE', 'PAYMENT_ADDED', 'PAYMENT_UPDATED', 'PAYMENT_DELETED', 'PRODUCT_ADDED', 'PRODUCT_UPDATED', 'PRODUCT_DELETED', 'ARCHIVE', 'UNARCHIVE', 'LOGIN', 'LOGOUT');--> statement-breakpoint
CREATE TABLE "leader_board" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"manager_id" bigint NOT NULL,
	"counsellor_id" bigint NOT NULL,
	"target" bigint NOT NULL,
	"achieved_target" bigint NOT NULL,
	"rank" bigint NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "activity_log" ALTER COLUMN "entity_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_log" ALTER COLUMN "action" SET DATA TYPE "public"."activity_action_enum" USING "action"::"public"."activity_action_enum";--> statement-breakpoint
ALTER TABLE "activity_log" ALTER COLUMN "performed_by" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "activity_log" ALTER COLUMN "user_agent" SET DATA TYPE varchar(500);--> statement-breakpoint
ALTER TABLE "activity_log" ADD COLUMN "client_id" bigint;--> statement-breakpoint
ALTER TABLE "activity_log" ADD COLUMN "description" text;--> statement-breakpoint
ALTER TABLE "activity_log" ADD COLUMN "metadata" jsonb;--> statement-breakpoint
ALTER TABLE "leader_board" ADD CONSTRAINT "leader_board_manager_id_users_id_fk" FOREIGN KEY ("manager_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "leader_board" ADD CONSTRAINT "leader_board_counsellor_id_users_id_fk" FOREIGN KEY ("counsellor_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "activity_log" ADD CONSTRAINT "activity_log_client_id_client_information_id_fk" FOREIGN KEY ("client_id") REFERENCES "public"."client_information"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "idx_activity_client" ON "activity_log" USING btree ("client_id");--> statement-breakpoint
CREATE INDEX "idx_activity_client_action" ON "activity_log" USING btree ("client_id","action");